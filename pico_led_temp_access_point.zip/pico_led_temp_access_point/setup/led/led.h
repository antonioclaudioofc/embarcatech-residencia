#include "pico/stdlib.h"

#define LED_RED 13

void setup_led(void);