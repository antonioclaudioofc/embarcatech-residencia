#define ADC_CHANNEL 4

void setup_temperature_sensor(void);
